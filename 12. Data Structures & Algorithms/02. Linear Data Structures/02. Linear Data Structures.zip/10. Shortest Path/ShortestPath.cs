﻿namespace _10.Shortest_Path
{
    using System;

    class ShortestPath
    {
        static void Main()
        {
            Console.WriteLine("N = ");
            var n = int.Parse(Console.ReadLine());
            Console.WriteLine("M = ");
            var m = int.Parse(Console.ReadLine());


        }
    }
}
