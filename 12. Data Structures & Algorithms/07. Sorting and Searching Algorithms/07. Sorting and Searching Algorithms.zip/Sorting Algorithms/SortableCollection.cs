﻿namespace Algorithms.Searchers
{
    using System;
    using System.Collections.Generic;
    using Contracts;

    public class SortableCollection<T> where T : IComparable<T>
    {
        private readonly IList<T> items;

        public SortableCollection()
        {
            this.items = new List<T>();
        }

        public SortableCollection(IEnumerable<T> items)
        {
            this.items = new List<T>(items);
        }

        public IList<T> Items
        {
            get
            {
                return this.items;
            }
        }

        public void Sort(ISorter<T> sorter)
        {
            sorter.Sort(this.items);
        }

        public bool LinearSearch(T item)
        {
            return this.Items.LinearSearch(item) != -1 ? true : false;
        }

        public bool BinarySearch(T item)
        {
            return this.Items.BinarySearch(item) != -1 ? true : false;
        }

        public void Shuffle()
        {
            this.Items.Shuffle();
        }

        public void PrintAllItemsOnConsole()
        {
            for (int i = 0; i < this.items.Count; i++)
            {
                if (i == 0)
                {
                    Console.Write(this.items[i]);
                }
                else
                {
                    Console.Write(" " + this.items[i]);
                }
            }

            Console.WriteLine();
        }
    }
}
