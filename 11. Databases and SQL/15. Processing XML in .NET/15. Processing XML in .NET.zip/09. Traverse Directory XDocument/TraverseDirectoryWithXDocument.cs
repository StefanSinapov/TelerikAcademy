﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09.Traverse_Directory_XDocument
{
    class TraverseDirectoryWithXDocument
    {
        static void Main(string[] args)
        {
        }
    }
}
