﻿namespace Company.DataGenerators.Contracts
{
    public interface IDataGenerator
    {
        void Seed();
    }
}