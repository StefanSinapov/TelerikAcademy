﻿namespace Company.DataGenerators.Contracts
{
    public interface ILogger
    {
        void Log(string text);
    }
}