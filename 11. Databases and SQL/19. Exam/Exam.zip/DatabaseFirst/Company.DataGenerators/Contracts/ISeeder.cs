﻿namespace Company.DataGenerators.Contracts
{
    public interface ISeeder
    {
        void SeedDatabaseWithRandomData();
    }
}