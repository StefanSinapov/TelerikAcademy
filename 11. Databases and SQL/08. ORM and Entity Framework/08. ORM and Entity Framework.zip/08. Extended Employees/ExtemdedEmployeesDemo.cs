﻿/*
 * 8. By inheriting the Employee entity class create a class which
 * allows employees to access their corresponding territories as
 * property of type EntitySet<T>.
 */
namespace _08.Extended_Employees
{
    class ExtemdedEmployeesDemo
    {
        static void Main()
        {
            // EntitySet<T> is not present 
        }
    }
}
