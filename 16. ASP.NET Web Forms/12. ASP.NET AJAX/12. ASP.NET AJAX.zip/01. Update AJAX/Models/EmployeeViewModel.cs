﻿namespace UpdateAjax.Models
{
    public class EmployeeViewModel
    {
        public int EmployeeID { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Title { get; set; }

        public string Address { get; set; }
    }
}