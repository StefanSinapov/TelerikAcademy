﻿using System.Web.UI;

namespace _02.Sum_with_WebForms.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}