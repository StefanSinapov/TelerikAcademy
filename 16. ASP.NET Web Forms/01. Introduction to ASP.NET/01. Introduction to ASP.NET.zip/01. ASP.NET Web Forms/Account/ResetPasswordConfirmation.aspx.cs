﻿using System.Web.UI;

namespace _01.ASP.NET_Web_Forms.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}