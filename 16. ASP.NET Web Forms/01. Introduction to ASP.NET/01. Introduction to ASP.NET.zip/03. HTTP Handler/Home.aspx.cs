﻿namespace _03.HTTP_Handler
{
    using System;
    using System.Web.UI;

    public partial class Home : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}