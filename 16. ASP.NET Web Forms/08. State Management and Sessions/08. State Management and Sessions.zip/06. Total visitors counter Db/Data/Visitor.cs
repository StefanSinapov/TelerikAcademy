﻿namespace VisitorsCounter.Data
{
    public class Visitor
    {
        public int Id { get; set; }
    }
}