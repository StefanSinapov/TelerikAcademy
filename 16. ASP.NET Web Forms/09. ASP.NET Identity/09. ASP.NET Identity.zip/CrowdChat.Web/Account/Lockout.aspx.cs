﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Lockout.aspx.cs" company="">
//   
// </copyright>
// <summary>
//   The lockout.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace CrowdChat.Web.Account
{
    using System;
    using System.Web.UI;

    /// <summary>
    /// The lockout.
    /// </summary>
    public partial class Lockout : Page
    {
        #region Methods

        /// <summary>
        /// The page_ load.
        /// </summary>
        /// <param name="sender">
        /// The sender.
        /// </param>
        /// <param name="e">
        /// The e.
        /// </param>
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        #endregion
    }
}