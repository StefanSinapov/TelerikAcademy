﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ResetPasswordConfirmation.aspx.cs" company="">
//   
// </copyright>
// <summary>
//   The reset password confirmation.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace CrowdChat.Web.Account
{
    using System.Web.UI;

    /// <summary>
    /// The reset password confirmation.
    /// </summary>
    public partial class ResetPasswordConfirmation : Page
    {
    }
}