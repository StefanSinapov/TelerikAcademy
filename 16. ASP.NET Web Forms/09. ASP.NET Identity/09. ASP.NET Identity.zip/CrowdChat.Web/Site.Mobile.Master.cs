// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Site.Mobile.Master.cs" company="">
//   
// </copyright>
// <summary>
//   The site_ mobile.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace CrowdChat.Web
{
    using System;
    using System.Web.UI;

    /// <summary>
    /// The site_ mobile.
    /// </summary>
    public partial class Site_Mobile : MasterPage
    {
        #region Methods

        /// <summary>
        /// The page_ load.
        /// </summary>
        /// <param name="sender">
        /// The sender.
        /// </param>
        /// <param name="e">
        /// The e.
        /// </param>
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        #endregion
    }
}