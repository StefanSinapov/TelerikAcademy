﻿using System.Web.UI;

namespace _02.Web_Forms_Application.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}