﻿namespace Articles.Web.Account
{
    using System.Web.UI;

    public partial class ResetPasswordConfirmation : Page
    {
    }
}