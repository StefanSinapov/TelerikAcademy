==========================================================
ASP.NET Universal Providers v2.0.0
==========================================================

----------------------------------------------------------
Overview
----------------------------------------------------------
ASP.NET Universal Providers are used to store membership, roles, profile and session data for your application.

For more information see http://go.microsoft.com/fwlink/?LinkID=320752&clcid=0x409

----------------------------------------------------------
Upgrade from v1.0.0 to v2.0.0
----------------------------------------------------------
When you are upgrading from v1.0.0 to v2.0.0, you will have to change the assembly references in your web.config to 2.0.0.
This is because the assembly version has changed from v1.0.0 to v2.0.0
