﻿namespace FileSystem.Common
{
    public class ConnectionStrings
    {
        public const string DefaultConnection = 
            @"Data Source=.;Initial Catalog=FileSystem;Integrated Security=True"; 
    }
}