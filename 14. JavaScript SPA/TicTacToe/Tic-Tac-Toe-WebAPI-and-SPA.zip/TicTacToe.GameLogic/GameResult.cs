namespace TicTacToe.GameLogic
{
    public enum GameResult
    {
        NotFinished,
        WonByX,
        WonByY,
        Draw,
    }
}