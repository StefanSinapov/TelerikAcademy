﻿namespace TicTacToe.Web.Infrastructure
{
    public interface IUserIdProvider
    {
        string GetUserId();
    }
}