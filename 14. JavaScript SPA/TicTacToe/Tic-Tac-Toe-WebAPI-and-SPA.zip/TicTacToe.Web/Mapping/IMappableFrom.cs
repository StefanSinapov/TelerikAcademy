﻿namespace TicTacToe.Web.Mapping
{
    public interface IMappableFrom<T>
    {
    }
}