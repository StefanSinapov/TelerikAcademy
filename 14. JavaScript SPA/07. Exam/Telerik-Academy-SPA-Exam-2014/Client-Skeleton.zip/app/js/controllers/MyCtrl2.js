'use strict';

app.controller('MyCtrl2', ['$scope', function($scope) {

}]);