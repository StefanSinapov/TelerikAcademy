ForumSystem
===========

Sample forums system like stackoverflow

TODO
===========

Connection strings -> .Common -> ConnectionStrings

user: admin@mail.com - admin@mail.com

AppHarbor: http://blogsystem-1.apphb.com/
