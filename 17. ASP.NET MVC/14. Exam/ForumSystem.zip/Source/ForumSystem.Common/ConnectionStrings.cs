﻿namespace ForumSystem.Common
{
    public class ConnectionStrings
    {
        public const string DefaultConnection = @"Data Source=.;Initial Catalog=ForumSystem;Integrated Security=True";

        public const string AppHarbor = @"Server=ebe4d095-dc8c-41b9-8e44-a3e600f23d10.sqlserver.sequelizer.com;Database=dbebe4d095dc8c41b98e44a3e600f23d10;User ID=seywitviaijyvnhy;Password=hnFcDTkmwK6j6UkVRFrun2VMRpGh3bnsiFQj3kd88TCRWNxojJptp6Upz2tomdrv;";
    }
}