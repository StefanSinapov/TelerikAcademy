namespace ForumSystem.Data.Migrations
{
    using System.Collections.Generic;
    using System.Data.Entity.Migrations;
    using System.Linq;

    using ForumSystem.Common;
    using ForumSystem.Data.Models;

    using Microsoft.AspNet.Identity;
    using Microsoft.AspNet.Identity.EntityFramework;

    internal sealed class Configuration : DbMigrationsConfiguration<ApplicationDbContext>
    {
        public Configuration()
        {
            this.AutomaticMigrationsEnabled = true;

            // TODO: Remove in production
            this.AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(ApplicationDbContext context)
        {
            this.SeedRoles(context);
            this.SeedUsers(context);
            this.SeedTags(context);
            this.SeedPosts(context);
        }

        private void SeedPosts(ApplicationDbContext context)
        {
            if (context.Posts.Any())
            {
                return;
            }

            var tags = context.Tags.ToList();
            var tagsCount = tags.Count;
            var userId = context.Users.Select(u => u.Id).FirstOrDefault();

            for (int i = 0; i < 15; i++)
            {
                var post = new Post
                               {
                                   AuthorId = userId,
                                   Content = RandomDataGenerator.Instance.GetRandomString(15, 60),
                                   Title = RandomDataGenerator.Instance.GetRandomString(5, 10),
                               };

                for (int j = 0; j < RandomDataGenerator.Instance.GetRandomInt(3, 10); j++)
                {
                    var tag = tags[RandomDataGenerator.Instance.GetRandomInt(0, tagsCount - 1)];
                    post.Tags.Add(tag);
                }

                context.Posts.Add(post);
            }

            context.SaveChanges();
        }

        private void SeedTags(ApplicationDbContext context)
        {
            if (context.Tags.Any())
            {
                return;
            }

            var tags = new List<Tag>();

            for (int i = 0; i < 30; i++)
            {
                tags.Add(new Tag
                             {
                                 Name = RandomDataGenerator.Instance.GetRandomString(2, 9)
                             });
            }

            context.Tags.AddOrUpdate(tags.ToArray());
            context.SaveChanges();
        }

        private void SeedUsers(ApplicationDbContext context)
        {
            if (context.Users.Any())
            {
                return;
            }

            var userManager = new UserManager<User>(new UserStore<User>(context));
            var admin = new User { UserName = GlobalConstants.AdministratorUserName, };
            admin.Email = admin.UserName;

            userManager.Create(admin, GlobalConstants.AdministratorUserPassword);
            userManager.AddToRole(admin.Id, GlobalConstants.AdministratorRoleName);

            for (int i = 0; i < 10; i++)
            {
                var user = new User
                {
                    Email =
                        string.Format(
                            "{0}@{1}.com",
                            RandomDataGenerator.Instance.GetRandomString(6, 16),
                            RandomDataGenerator.Instance.GetRandomString(6, 16)),
                    UserName = RandomDataGenerator.Instance.GetRandomString(6, 16)
                };

                userManager.Create(user, GlobalConstants.AdministratorUserPassword);
            }

            context.SaveChanges();
        }

        private void SeedRoles(ApplicationDbContext context)
        {
            if (context.Roles.Any())
            {
                return;
            }

            var roleStore = new RoleStore<IdentityRole>(context);
            var roleManager = new RoleManager<IdentityRole>(roleStore);

            var adminRole = new IdentityRole { Name = GlobalConstants.AdministratorRoleName };
            roleManager.Create(adminRole);

            context.SaveChanges();
        }
    }
}
