﻿namespace ForumSystem.Web.ViewModels.Votes
{
    public class VoteViewModel
    {
        public int PostId { get; set; }

        public int Count { get; set; }

        public bool? CurrentUserVote { get; set; }
    }
}