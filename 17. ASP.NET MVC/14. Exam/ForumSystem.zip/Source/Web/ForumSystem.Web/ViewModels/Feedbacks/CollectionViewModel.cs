﻿namespace ForumSystem.Web.ViewModels.Feedbacks
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// collection view model
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class CollectionViewModel<T>
    {
        public CollectionViewModel(IEnumerable<T> collection)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("collection");
            }

            this.Collection = collection;
        }

        public CollectionViewModel(IEnumerable<T> collection, PagerSettings pager)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("collection");
            }

            this.Collection = collection;
            this.Records = pager.Records;
            this.PageIndex = pager.PageIndex;
            this.PageSize = pager.PageSize;
        }

        #region public properties
        /// <summary>
        /// collection
        /// </summary>
        public IEnumerable<T> Collection { get; private set; }

        /// <summary>
        /// page index
        /// </summary>
        public int PageIndex { get; set; }

        /// <summary>
        /// page size
        /// </summary>
        public int PageSize { get; set; }

        /// <summary>
        /// records
        /// </summary>
        public int Records { get; private set; }
        #endregion
    }
}