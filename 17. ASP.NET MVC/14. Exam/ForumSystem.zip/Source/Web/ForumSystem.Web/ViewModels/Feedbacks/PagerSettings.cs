﻿namespace ForumSystem.Web.ViewModels.Feedbacks
{
    public class PagerSettings
    {
        public PagerSettings()
        {
        }

        public PagerSettings(int pageIndex, int pageSize)
        {
            this.PageIndex = pageIndex;
            this.PageSize = pageSize;
        }

        /// <summary>
        /// page index
        /// </summary>
        public int PageIndex { get; set; }

        /// <summary>
        /// page size
        /// </summary>
        public int PageSize { get; set; }

        /// <summary>
        /// records
        /// </summary>
        public int Records { get; set; }
    
        public static PagerSettings From(int pageIndex, int pageSize)
        {
            return new PagerSettings(pageIndex, pageSize);
        }
    }
}