﻿namespace ForumSystem.Web.Controllers
{
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;
    using System.Web.Routing;

    using ForumSystem.Data.Common.Repository;
    using ForumSystem.Data.Models;
    using ForumSystem.Web.ViewModels.Votes;

    using Microsoft.AspNet.Identity;

    public class VotesController : Controller
    {
        private readonly IDeletableEntityRepository<Vote> votes;

        private readonly IDeletableEntityRepository<Post> posts;

        public VotesController(IDeletableEntityRepository<Vote> votes, IDeletableEntityRepository<Post> posts)
        {
            this.votes = votes;
            this.posts = posts;
        }

        [HttpGet]
        public ActionResult GetVotes(int id)
        {
            var postVotes = this.posts.All().Where(p => p.Id == id).Select(v => v.Votes).FirstOrDefault();

            if (postVotes == null)
            {
                throw new HttpException(404, "Post not found");
            }

            var viewModel = new VoteViewModel
                              {
                                  PostId = id
                              };

            var positiveCount = postVotes.Count(v => v.Value == true);
            var negativeCount = postVotes.Count(v => v.Value == false);

            viewModel.Count = positiveCount - negativeCount;

            if (this.User.Identity.IsAuthenticated)
            {
                var userId = this.User.Identity.GetUserId();
                var userVote = postVotes.FirstOrDefault(v => v.AuthorId == userId);
                if (userVote != null)
                {
                    viewModel.CurrentUserVote = userVote.Value;
                }
            }

            return this.PartialView("_VotePartial", viewModel);
        }

        [HttpGet]
        public ActionResult Up(int id)
        {
            return this.HandleVote(id, true);
        }

        [HttpGet]
        public ActionResult Down(int id)
        {
            return this.HandleVote(id, false);
        }

        private ActionResult HandleVote(int id, bool value)
        {
            if (!this.User.Identity.IsAuthenticated)
            {
                return this.PartialView("_PageLoginPartial");
            }

            var userId = this.User.Identity.GetUserId();

            var post = this.posts.GetById(id);

            if (post == null)
            {
                throw new HttpException(404, "Post not found");
            }

            var userVote = post.Votes.FirstOrDefault(v => v.AuthorId == userId);

            if (userVote != null)
            {
                userVote.Value = value;
            }
            else
            {
                post.Votes.Add(new Vote { AuthorId = userId, Value = value });
            }

            this.posts.Update(post);
            this.posts.SaveChanges();

            return this.RedirectToAction("GetVotes", new { id });
        }
    }
}