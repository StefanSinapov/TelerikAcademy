﻿namespace ForumSystem.Web.Controllers
{
    using System.Web.Mvc;

    using ForumSystem.Data.Common.Repository;
    using ForumSystem.Data.Models;
    using ForumSystem.Web.Infrastructure;
    using ForumSystem.Web.InputModels.Feedbacks;

    using Microsoft.AspNet.Identity;

    public class FeedbacksController : Controller
    {
        private readonly IDeletableEntityRepository<Feedback> feedbacks;

        private readonly ISanitizer sanitizer;

        public FeedbacksController(IDeletableEntityRepository<Feedback> feedbacks, ISanitizer sanitizer)
        {
            this.feedbacks = feedbacks;
            this.sanitizer = sanitizer;
        }

        [HttpGet]
        public ActionResult Create()
        {
            var model = new FeedbackInputModel();
            return this.View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(FeedbackInputModel model)
        {
            if (model != null && ModelState.IsValid)
            {
                var feedback = new Feedback
                                   {
                                       Content = this.sanitizer.Sanitize(model.Content),
                                       Title = model.Title,
                                       AuthorId = this.User.Identity.GetUserId()
                                   };

                this.feedbacks.Add(feedback);
                this.feedbacks.SaveChanges();

                this.TempData.Add("Success", "Feedback created successfully");
                return this.RedirectToAction("Index", "Home");
            }

            return this.View(model);
        }
    }
}