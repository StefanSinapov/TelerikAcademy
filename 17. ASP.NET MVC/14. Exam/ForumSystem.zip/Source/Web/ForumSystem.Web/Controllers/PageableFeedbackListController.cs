﻿namespace ForumSystem.Web.Controllers
{
    using System.Linq;
    using System.Web.Mvc;

    using AutoMapper.QueryableExtensions;

    using ForumSystem.Data.Common.Repository;
    using ForumSystem.Data.Models;
    using ForumSystem.Web.ViewModels.Feedbacks;

    [Authorize]
    public class PageableFeedbackListController : Controller
    {
        private const int PageSize = 4;

        private readonly IDeletableEntityRepository<Feedback> feedbacks;

        public PageableFeedbackListController(IDeletableEntityRepository<Feedback> feedbacks)
        {
            this.feedbacks = feedbacks;
        }

        [HttpGet]
        [OutputCache(Duration = 1 * 60 * 5, VaryByParam = "page")] // Five minutes for test purposes
        public ActionResult Index(int page = 1)
        {
            var pager = PagerSettings.From(page, PageSize);
            pager.Records = this.feedbacks.All().Count();
            var models = this.feedbacks
                    .All()
                    .OrderBy(f => f.Id)
                    .Skip((page - 1) * PageSize)
                    .Take(PageSize)
                    .Project().To<FeedbackViewModel>();

            var viewModel = new CollectionViewModel<FeedbackViewModel>(models, pager);

            return this.View(viewModel);
        }
    }
}