﻿namespace ForumSystem.Web.Areas.Administration.Controllers
{
    using System.Collections;
    using System.Web.Mvc;

    using AutoMapper;
    using AutoMapper.QueryableExtensions;

    using ForumSystem.Data.Common.Repository;
    using ForumSystem.Data.Models;
    using ForumSystem.Web.Areas.Administration.Controllers.Base;
    using ForumSystem.Web.Areas.Administration.ViewModels.Posts;
    using ForumSystem.Web.Infrastructure;

    using Kendo.Mvc.UI;

    using Microsoft.AspNet.Identity;

    using Model = ForumSystem.Data.Models.Post;
    using ViewModel = ForumSystem.Web.Areas.Administration.ViewModels.Posts.PostsAdministrationViewModel;

    public class PostsController : KendoGridAdminController
    {
        private readonly IDeletableEntityRepository<Post> posts;

        private readonly ISanitizer sanitizer;

        public PostsController(IDeletableEntityRepository<Post> posts, ISanitizer sanitizer)
        {
            this.posts = posts;
            this.sanitizer = sanitizer;
        }

        public ActionResult Index()
        {
            return this.View();
        }

        [HttpPost]
        public ActionResult Update([DataSourceRequest] DataSourceRequest request, PostInputModel model)
        {
            if (model != null && ModelState.IsValid)
            {
                var dataModel = this.posts.GetById(model.Id);
                dataModel.Title = model.Title;
                dataModel.Content = this.sanitizer.Sanitize(model.Content);

                this.posts.Update(dataModel);
                this.posts.SaveChanges();
                var viewModel = Mapper.Map<PostsAdministrationViewModel>(dataModel);
                return this.GridOperation(viewModel, request);
            }

            return this.GridOperation(model, request);
        }

        [Authorize]
        [HttpPost]
        public ActionResult Create([DataSourceRequest]DataSourceRequest request, PostInputModel model)
        {
            if (model != null && ModelState.IsValid)
            {
                var userId = this.User.Identity.GetUserId();
                var dataModel = new Post
                {
                    AuthorId = userId,
                    Title = model.Title,
                    Content = this.sanitizer.Sanitize(model.Content)
                };

                this.posts.Add(dataModel);
                var viewModel = Mapper.Map<PostsAdministrationViewModel>(dataModel);
                return this.GridOperation(viewModel, request);
            }

            return this.GridOperation(model, request);
        }

        [HttpPost]
        public ActionResult Destroy([DataSourceRequest]DataSourceRequest request, PostInputModel model)
        {
            if (model != null && ModelState.IsValid)
            {
                this.posts.Delete(model.Id);
                this.posts.SaveChanges();
            }

            return this.GridOperation(model, request);
        }

        protected override IEnumerable GetData()
        {
            return this.posts.All().Project().To<PostsAdministrationViewModel>();
        }

        protected override T GetById<T>(object id)
        {
            return this.posts.GetById(id) as T;
        }
    }
}