﻿namespace ForumSystem.Web.Areas.Administration.Controllers.Base
{
    using System.Web.Mvc;

    using ForumSystem.Common;

   /* [Authorize(Roles = GlobalConstants.AdministratorRoleName)]*/
    public abstract class AdminController : Controller
    {
        /*
        protected AdminController()
            : base(data)
        {
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                this.Data.Dispose();
            }

            base.Dispose(disposing);
        }*/
    }
}