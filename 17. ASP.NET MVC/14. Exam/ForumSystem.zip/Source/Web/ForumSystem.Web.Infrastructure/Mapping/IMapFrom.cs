﻿namespace ForumSystem.Web.Infrastructure.Mapping
{
    public interface IMapFrom<T>
    {
    }
}