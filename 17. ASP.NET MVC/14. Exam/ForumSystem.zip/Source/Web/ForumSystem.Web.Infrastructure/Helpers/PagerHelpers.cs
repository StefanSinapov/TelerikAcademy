﻿namespace ForumSystem.Web.Infrastructure.Helpers
{
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Text;
    using System.Web;
    using System.Web.Mvc;

    public static class PagerHelpers
    {
        public static HtmlString RenderPager(this HtmlHelper html, string controllerName, string actionName, int recordNumber, int pageSize, int currentPage)
        {
            // calculate the number of pages
            var numberOfPages = recordNumber / pageSize;
            if (recordNumber % pageSize != 0)
            {
                ++numberOfPages;
            }

            if (numberOfPages < 2)
            {
                return new HtmlString(string.Empty);
            }

            var urlHelper = new UrlHelper(html.ViewContext.RequestContext, html.RouteCollection);
            var link = urlHelper.Action(actionName, controllerName);

            var builder = new StringBuilder();

            builder.Append("<ul class=\"pagination\">");
            if (currentPage > 1)
            {
                AppendPagerTag(builder, currentPage - 1, urlHelper, controllerName, actionName, currentPage, "&laquo;");
            }

            // the first section contains the first pages
            IEnumerable<int> section1 = new[] { 1, 2, 3 }.ToList();

            // the last section contains the last pages
            IEnumerable<int> section3 = new[] { numberOfPages - 2, numberOfPages - 1, numberOfPages }.ToList();

            // calculate the floating middle section. If the current page is in the middle, the floating section is a region that
            // contains the current page otherwise, it's the region that contains the middle pages
            int middleStart;
            if ((currentPage <= 2) || (currentPage >= numberOfPages - 1))
            {
                middleStart = numberOfPages / 2;
                if (middleStart < 5)
                {
                    middleStart = 5;
                }
            }
            else if ((currentPage >= 3) && (currentPage < 6) && (currentPage < numberOfPages - 2))
            {
                middleStart = 5;
            }
            else
            {
                middleStart = currentPage;
            }

            var middle = new[] { middleStart - 1, middleStart, middleStart + 1 };

            // create the list of pages that are composed of the three sections and eventual separators that are represented by negative numbers (-99 and -98)
            IEnumerable<int> pages = section1;
            if (middle.First() > 4)
            {
                pages = pages.Union(new[] { -98 });
            }

            pages = pages.Union(middle);
            if (middle.Last() < numberOfPages - 3)
            {
                pages = pages.Union(new[] { -99 });
            }

            // filter the pages to take into account only the coherent pages by eliminating redundancies and illogical pages
            foreach (var page in pages.Where(e => (e <= numberOfPages && e > 0) || e == -99 || e == -98).Distinct())
            {
                if (page > 0)
                {
                    AppendPagerTag(builder, page, urlHelper, controllerName, actionName, currentPage);
                }
                else
                {
                    AppendPagerTag(builder, page, urlHelper, controllerName, actionName, currentPage, "...");
                }
            }

            // generate the next page if we are not in the last page
            if (currentPage < numberOfPages)
            {
                AppendPagerTag(builder, currentPage + 1, urlHelper, controllerName, actionName, currentPage, "&raquo;");
            }

            // generate the next page if we are not in the last page
            if (currentPage < numberOfPages)
            {
                AppendPagerTag(builder, currentPage + 1, urlHelper, controllerName, actionName, currentPage, "&raquo;");
            }

            builder.AppendFormat("</ul>");
            return new HtmlString(builder.ToString());
        }

        private static void AppendPagerTag(StringBuilder builder, int targetPage, UrlHelper helper, string controllerName, string actionName, int currentPage, string tagText = null)
        {
            // the link markup
            string linkTag;

            // the active css
            string activeCss = string.Empty;

            // the page text
            if (tagText == null)
            {
                tagText = targetPage.ToString(CultureInfo.InvariantCulture);
            }

            // a positive value of targetPage points to a real page while a negative value points to a simple text (span)
            if (targetPage > 0)
            {
                // if the target page is the current page, then we'll add the "active" class to the item
                if (targetPage == currentPage)
                {
                    activeCss = "active";
                }

                var link = helper.Action(actionName, controllerName, new { page = targetPage });

                // generate the link markup
                linkTag = string.Format("<a href=\"{1}\">{0}</a>", tagText, link);
            }
            else
            {
                // generates the separator markup
                linkTag = string.Format("<span>{0}</span>", tagText);
            }

            // embed the generated markup in a list item
            builder.AppendFormat("<li class=\"{1}\">{0}</li>", linkTag, activeCss);
        }
    }
}