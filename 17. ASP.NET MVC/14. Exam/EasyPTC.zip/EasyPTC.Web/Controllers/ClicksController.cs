﻿namespace EasyPTC.Web.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;

    using AutoMapper.QueryableExtensions;

    using EasyPTC.Common;
    using EasyPTC.Data;
    using EasyPTC.Web.Areas.Administration.ViewModels.Advertisements;
    using EasyPTC.Web.ViewModels;

    public class ClicksController : BaseController
    {
        public ClicksController(IEasyPtcData data)
            : base(data)
        {
        }

        [HttpGet]
        /*[ChildActionOnly]*/
        public ActionResult GetBanners(int count = 3)
        {
            var bannersCount = this.Data.Banners.All().Count();

            if (bannersCount <= 0)
            {
                return this.PartialView("_BannersPartial", new List<BannerViewModel>());
            }

            var bannersToSkip = RandomDataGenerator.Instance.GetRandomInt(0, bannersCount - count);

            var banners =
                this.Data.Banners.All()
                    .OrderBy(b => b.Id)
                    .Skip(bannersToSkip)
                    .Take(count)
                    .Project()
                    .To<BannerViewModel>().ToList();

            return this.PartialView("_BannersPartial", banners);
        }

        [HttpGet]
        public ActionResult GetAds()
        {
            var ads = this.Data.Advertisements.All().Project()
                    .To<AdvertisementViewModel>().ToList();

            return this.PartialView("_AdsPartial", ads);
        }

        public ActionResult RegisterBannerClick(int id)
        {
            var banner = this.Data.Banners.GetById(id);

            if (banner == null)
            {
                throw new HttpException(404, "Banner not found");
            }

            banner.TotalClicks++;
            banner.AvailableClicks--;
            this.Data.Banners.Update(banner);
            this.Data.SaveChanges();
            return this.Redirect(banner.Url);
        } 
        
        public ActionResult RegisterAdClick(int id)
        {
            var ad = this.Data.Advertisements.GetById(id);

            if (ad == null)
            {
                throw new HttpException(404, "Banner not found");
            }

            ad.TotalClicks++;
            ad.AvailableClicks--;
            this.Data.Advertisements.Update(ad);
            this.Data.SaveChanges();

            return this.Redirect(ad.Url);
        }
    }
}