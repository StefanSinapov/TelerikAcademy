﻿namespace EasyPTC.Models
{
    using System.ComponentModel.DataAnnotations;

    using EasyPTC.Data.Contracts;

    public class Banner : DeletableEntity, IEntity
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string Url { get; set; }

        [Required]
        public string ImageUrl { get; set; }

        [Required]
        public int AvailableClicks { get; set; }

        public int TotalClicks { get; set; }
    }
}