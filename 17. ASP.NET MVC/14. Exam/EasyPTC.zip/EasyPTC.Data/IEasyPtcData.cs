﻿namespace EasyPTC.Data
{
    using EasyPTC.Data.Contracts;
    using EasyPTC.Models;

    public interface IEasyPtcData
    {
        IEasyPtcDbContext Context { get; }

        IDeletableEntityRepository<Advertisement> Advertisements { get; }

        IDeletableEntityRepository<Banner> Banners { get; }

        IDeletableEntityRepository<Category> Categories { get; }

        IRepository<Image> Images { get; }

        IRepository<User> Users { get; }

        int SaveChanges();
    }
}
