namespace EasyPTC.Data.Migrations
{
    using System.Data.Entity.Migrations;
    using System.Linq;

    using EasyPTC.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<EasyPtcDbContext>
    {
        public Configuration()
        {
            this.AutomaticMigrationsEnabled = true;
            this.AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(EasyPtcDbContext context)
        {
            this.SeedAds(context);
            this.SeedBanners(context);
        }

        private void SeedBanners(EasyPtcDbContext context)
        {
            if (context.Banners.Any())
            {
                return;
            }

            context.Banners.AddOrUpdate(
                a => a.Id,
                new Banner
                    {
                        Name = "Zamunda.NET",
                        AvailableClicks = 500,
                        Url = "http://www.zamunda.net",
                        ImageUrl = "http://ads2.zamunda.net/banners/8/0a2e5c8b07a94218.gif"
                    },
             new Banner
                    {
                        Name = "Zamunda.NET",
                        AvailableClicks = 500,
                        Url = "http://www.zamunda.net",
                        ImageUrl = "http://ads2.zamunda.net/banners/8/8106cf6e567296f6.gif"
                    },
             new Banner
                    {
                        Name = "Zamunda.NET",
                        AvailableClicks = 500,
                        Url = "http://www.zamunda.net",
                        ImageUrl = "http://ads2.zamunda.net/banners/8/0a2e5c8b07a94218.gif"
                    },
             new Banner
                    {
                        Name = "Zamunda.NET",
                        AvailableClicks = 500,
                        Url = "http://www.zamunda.net",
                        ImageUrl = "http://ads2.zamunda.net/banners/8/8106cf6e567296f6.gif"
                    });
        }

        private void SeedAds(EasyPtcDbContext context)
        {
            context.Advertisements.AddOrUpdate(
                a => a.Id,
                new Advertisement
                    {
                        Name = "We are cool",
                        AvailableClicks = 500,
                        Url = "http://www.telerikacademy.com",
                    },
                new Advertisement
                {
                    Name = "We are cool 1",
                    AvailableClicks = 500,
                    Url = "http://www.telerikacademy.com",
                },
                new Advertisement
                    {
                        Name = "We are cool 2",
                        AvailableClicks = 500,
                        Url = "http://www.telerikacademy.com",
                    },
                new Advertisement
                {
                    Name = "We are cool",
                    AvailableClicks = 500,
                    Url = "http://www.telerikacademy.com",
                },
                new Advertisement
                {
                    Name = "We are cool 1",
                    AvailableClicks = 500,
                    Url = "http://www.telerikacademy.com",
                },
                new Advertisement
                    {
                        Name = "We are cool 2",
                        AvailableClicks = 500,
                        Url = "http://www.telerikacademy.com",
                    },
                new Advertisement
                    {
                        Name = "We are cool",
                        AvailableClicks = 500,
                        Url = "http://www.telerikacademy.com",
                    },
                new Advertisement
                {
                    Name = "We are cool 1",
                    AvailableClicks = 500,
                    Url = "http://www.telerikacademy.com",
                },
                new Advertisement
                    {
                        Name = "We are cool 2",
                        AvailableClicks = 500,
                        Url = "http://www.telerikacademy.com",
                    },
                new Advertisement
                    {
                        Name = "We are cool",
                        AvailableClicks = 500,
                        Url = "http://www.telerikacademy.com",
                    },
                new Advertisement
                {
                    Name = "We are cool 1",
                    AvailableClicks = 500,
                    Url = "http://www.telerikacademy.com",
                },
                new Advertisement
                    {
                        Name = "We are cool 2",
                        AvailableClicks = 500,
                        Url = "http://www.telerikacademy.com",
                    },
                new Advertisement
                    {
                        Name = "We are cool",
                        AvailableClicks = 500,
                        Url = "http://www.telerikacademy.com",
                    },
                new Advertisement
                {
                    Name = "We are cool 1",
                    AvailableClicks = 500,
                    Url = "http://www.telerikacademy.com",
                },
                new Advertisement
                    {
                        Name = "We are cool 2",
                        AvailableClicks = 500,
                        Url = "http://www.telerikacademy.com",
                    },
                new Advertisement
                    {
                        Name = "We are cool",
                        AvailableClicks = 500,
                        Url = "http://www.telerikacademy.com",
                    },
                new Advertisement
                {
                    Name = "We are cool 1",
                    AvailableClicks = 500,
                    Url = "http://www.telerikacademy.com",
                },
                new Advertisement
                    {
                        Name = "We are cool 2",
                        AvailableClicks = 500,
                        Url = "http://www.telerikacademy.com",
                    },
                new Advertisement
                    {
                        Name = "We are cool",
                        AvailableClicks = 500,
                        Url = "http://www.telerikacademy.com",
                    },
                new Advertisement
                {
                    Name = "We are cool 1",
                    AvailableClicks = 500,
                    Url = "http://www.telerikacademy.com",
                },
                new Advertisement
                    {
                        Name = "We are cool",
                        AvailableClicks = 500,
                        Url = "http://www.telerikacademy.com",
                    },
                new Advertisement
                {
                    Name = "We are cool 1",
                    AvailableClicks = 500,
                    Url = "http://www.telerikacademy.com",
                },
                new Advertisement
                    {
                        Name = "We are cool",
                        AvailableClicks = 500,
                        Url = "http://www.telerikacademy.com",
                    },
                new Advertisement
                {
                    Name = "We are cool 1",
                    AvailableClicks = 500,
                    Url = "http://www.telerikacademy.com",
                });
        }
    }
}
