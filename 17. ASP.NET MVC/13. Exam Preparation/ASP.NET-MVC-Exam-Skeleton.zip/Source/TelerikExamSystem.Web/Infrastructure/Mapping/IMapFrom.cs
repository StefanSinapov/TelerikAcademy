﻿namespace TelerikExamSystem.Web.Infrastructure.Mapping
{
    using System;
    using System.Linq;

    public interface IMapFrom<T>
    {
    }
}