﻿namespace ExamApplication.Common
{
    public class ConnectionStrings
    {
        public const string DefaultConnection = @"Data Source=.;Initial Catalog=ExamApplication;Integrated Security=True";
    }
}