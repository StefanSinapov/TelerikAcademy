$.fn.tabs = function () {

};