package com.team.blaze.models;

public enum ConnectionType
{
    JDBC(),
    JDNI(),
    Default;
}
