/*
 *   Initializes the game.
 */
function init() {
    var game = new Game();
    game.start();
}

/*
 *  On window load function.
 */
window.onload = init;