﻿using System;
using System.Linq;


namespace Plane
{
    public enum ObjectTypes
    {
        Plane = 0,
        Rocket = 2,
        Asteroid = 1
    }
}
