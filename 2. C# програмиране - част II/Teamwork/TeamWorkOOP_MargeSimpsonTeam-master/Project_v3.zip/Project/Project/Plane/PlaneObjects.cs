﻿//using System;


//namespace Plane
//{
//    public class Plane : GameObject
//    {
//        public PlaneObjects(Coord center,char[,] image)
//            :base(center,image)
//        {
//        }


//    }
//}
