﻿using System;

namespace LabirynthGame
{
    class LabirynthTest
    {
        static void Main()
        {
            Labirynth test = new Labirynth();
            test.PlayGame();
        }
    }
}