﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RandomNews.Models
{
    public class NewsModel
    {
        public string Title { get; set; }
        public string Url { get; set; }
    }
}