﻿namespace BullsAndCows.Models.Enums
{
    public enum GameState
    {
        WaitingForOpponent,
        RedInTurn,
        BlueInTurn,
        Finished
    }
}