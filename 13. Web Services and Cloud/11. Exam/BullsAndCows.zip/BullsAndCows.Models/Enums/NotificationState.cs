﻿namespace BullsAndCows.Models.Enums
{
    public enum NotificationState
    {
        Unread,
        Read
    }
}