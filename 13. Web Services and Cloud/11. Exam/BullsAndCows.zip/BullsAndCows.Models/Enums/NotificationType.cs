﻿namespace BullsAndCows.Models.Enums
{
    public enum NotificationType
    {
        YourTurn,
        GameWon,
        GameLost,
        GameJoined
    }
}