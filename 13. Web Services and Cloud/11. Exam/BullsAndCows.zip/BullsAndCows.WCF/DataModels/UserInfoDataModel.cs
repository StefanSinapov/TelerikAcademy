﻿namespace BullsAndCows.WCF.DataModels
{
    public class UserInfoDataModel
    {
        public string Id { get; set; }

        public int Losses { get; set; }

        public int Rank { get; set; }

        public string Username { get; set; }

        public int Wins { get; set; }
    }
}