﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BugLogger.DataLayer
{
    public enum Status { Pending, Assigned, Fixed }
}
