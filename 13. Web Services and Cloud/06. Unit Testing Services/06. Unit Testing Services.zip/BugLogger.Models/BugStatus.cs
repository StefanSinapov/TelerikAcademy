﻿namespace BugLogger.Models
{
    public enum BugStatus
    {
        Fixed,
        Assigned,
        ForTesting,
        Pending
    }
}