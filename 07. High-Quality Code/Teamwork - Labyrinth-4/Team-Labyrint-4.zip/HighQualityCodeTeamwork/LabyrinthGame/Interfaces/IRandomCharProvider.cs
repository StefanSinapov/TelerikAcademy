﻿namespace LabyrinthGame.Interfaces
{
    public interface IRandomCharProvider
    {
        char GetRandomSymbol(int chance);
    }
}