var interface_labyrinth_game_1_1_interfaces_1_1_i_coordinate =
[
    [ "Update", "interface_labyrinth_game_1_1_interfaces_1_1_i_coordinate.html#ac898b2b5a6f3d7ba942d54c3815c97f8", null ],
    [ "Col", "interface_labyrinth_game_1_1_interfaces_1_1_i_coordinate.html#ae21b7a7e0ba1b797254b38088f76693a", null ],
    [ "Row", "interface_labyrinth_game_1_1_interfaces_1_1_i_coordinate.html#aa75fdf8b6ec615d943533ba6b360a89c", null ]
];