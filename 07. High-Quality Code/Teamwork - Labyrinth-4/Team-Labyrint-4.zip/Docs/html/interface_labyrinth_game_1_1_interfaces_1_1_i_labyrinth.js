var interface_labyrinth_game_1_1_interfaces_1_1_i_labyrinth =
[
    [ "ChangeSymbol", "interface_labyrinth_game_1_1_interfaces_1_1_i_labyrinth.html#a921c8376d2a59e784f1e95b355722b0a", null ],
    [ "FillMatrix", "interface_labyrinth_game_1_1_interfaces_1_1_i_labyrinth.html#a949a13949711b621a487d3efcd37b0eb", null ],
    [ "Matrix", "interface_labyrinth_game_1_1_interfaces_1_1_i_labyrinth.html#af48030cf8898560b662ac445edc11acd", null ]
];