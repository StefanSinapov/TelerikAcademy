var class_labyrinth_game_1_1_player =
[
    [ "Player", "class_labyrinth_game_1_1_player.html#a7d499ce5268336b48d35fc7ba4d10282", null ],
    [ "RemovePlayer", "class_labyrinth_game_1_1_player.html#ae995caf4d9b284a112e7b6af8951b647", null ],
    [ "ShowPlayer", "class_labyrinth_game_1_1_player.html#a26d87cb40ba995b3c5a6367f14916b4e", null ],
    [ "UpdatePoints", "class_labyrinth_game_1_1_player.html#afd1b29af63a3d8b35232e0351be66ec7", null ],
    [ "UpdatePosition", "class_labyrinth_game_1_1_player.html#a17d185d5d645ca708341a8edda507b39", null ],
    [ "Coordinates", "class_labyrinth_game_1_1_player.html#a506310cd8dbc411f374cd8d12f309ac7", null ],
    [ "Name", "class_labyrinth_game_1_1_player.html#abd56f30d9d6c80f303b858680e747121", null ],
    [ "Points", "class_labyrinth_game_1_1_player.html#a3914950908e30f2a3583f2b13565d485", null ]
];