var class_labyrinth_game_1_1_score =
[
    [ "AddScore", "class_labyrinth_game_1_1_score.html#a264649a0a5a33dee022dc1a94ab85c9f", null ],
    [ "PrintScoreBoard", "class_labyrinth_game_1_1_score.html#a7f8fff906c41948227a16058b09214a7", null ],
    [ "ScoreBoard", "class_labyrinth_game_1_1_score.html#a52d40b8e5b17e6fc7e8a62b63072c6aa", null ]
];