var namespace_labyrinth_game_1_1_labyrinths =
[
    [ "DiamondLabyrinth", "class_labyrinth_game_1_1_labyrinths_1_1_diamond_labyrinth.html", "class_labyrinth_game_1_1_labyrinths_1_1_diamond_labyrinth" ],
    [ "HexagonalLabyrinth", "class_labyrinth_game_1_1_labyrinths_1_1_hexagonal_labyrinth.html", "class_labyrinth_game_1_1_labyrinths_1_1_hexagonal_labyrinth" ],
    [ "Labyrinth", "class_labyrinth_game_1_1_labyrinths_1_1_labyrinth.html", "class_labyrinth_game_1_1_labyrinths_1_1_labyrinth" ],
    [ "PentagonLabyrinth", "class_labyrinth_game_1_1_labyrinths_1_1_pentagon_labyrinth.html", "class_labyrinth_game_1_1_labyrinths_1_1_pentagon_labyrinth" ],
    [ "SquareLabyrinth", "class_labyrinth_game_1_1_labyrinths_1_1_square_labyrinth.html", "class_labyrinth_game_1_1_labyrinths_1_1_square_labyrinth" ]
];