var class_labyrinth_game_test_1_1_coordinate_test =
[
    [ "ColCoordinateUpdateTest", "class_labyrinth_game_test_1_1_coordinate_test.html#a7c280bfc815c75f41dc8eeafa18284dd", null ],
    [ "CoordinateUpdateWithNegativeTest", "class_labyrinth_game_test_1_1_coordinate_test.html#ab639f37f54a20e71512d00cca30ee6ee", null ],
    [ "RowCoordinateUpdateTest", "class_labyrinth_game_test_1_1_coordinate_test.html#a0db2897fc8f242a3ba6f155b4374a4e1", null ],
    [ "SubstractionOfBiggerCoordinatesShouldReturnNewCoordinateTest", "class_labyrinth_game_test_1_1_coordinate_test.html#a2b36e28c7def15a0ec3bd14877fe410e", null ],
    [ "SubstractionOfCoordinatesShouldReturnNewCoordinateTest", "class_labyrinth_game_test_1_1_coordinate_test.html#a094a760e28bdc165023223ae80410ffc", null ]
];