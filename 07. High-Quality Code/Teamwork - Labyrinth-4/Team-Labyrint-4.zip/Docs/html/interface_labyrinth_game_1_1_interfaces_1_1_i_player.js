var interface_labyrinth_game_1_1_interfaces_1_1_i_player =
[
    [ "RemovePlayer", "interface_labyrinth_game_1_1_interfaces_1_1_i_player.html#a3879574fee6f751f8b967697cb07b21c", null ],
    [ "ShowPlayer", "interface_labyrinth_game_1_1_interfaces_1_1_i_player.html#a95f66bba326c5034c5b37b89d93a2502", null ],
    [ "UpdatePoints", "interface_labyrinth_game_1_1_interfaces_1_1_i_player.html#ac5434e0343d317b160fda2624bac1fb5", null ],
    [ "UpdatePosition", "interface_labyrinth_game_1_1_interfaces_1_1_i_player.html#a90eec2568366b814e522982d2dbb4c8d", null ],
    [ "Coordinates", "interface_labyrinth_game_1_1_interfaces_1_1_i_player.html#a78df99d940e4e8cb40215ebcc2319809", null ],
    [ "Name", "interface_labyrinth_game_1_1_interfaces_1_1_i_player.html#ada91c3312fd708c5c66da510529a5602", null ],
    [ "Points", "interface_labyrinth_game_1_1_interfaces_1_1_i_player.html#aaa644f1f84177bdf8760bef94f9c8467", null ]
];