var class_labyrinth_game_1_1_menu =
[
    [ "GetLabyrinthTypeFromUser", "class_labyrinth_game_1_1_menu.html#a48e4db8ff35a86dc421e013cbd986f5e", null ],
    [ "GetUserChoice", "class_labyrinth_game_1_1_menu.html#ad23587aa48dd1a0c0ce0774f25d1ca5b", null ],
    [ "MainMenu", "class_labyrinth_game_1_1_menu.html#ad1afd5a0a2a768cb8657b8f6a4aebda2", null ],
    [ "MenuDuringPlay", "class_labyrinth_game_1_1_menu.html#a30ae1129b472cba53f84ab34186b791b", null ]
];