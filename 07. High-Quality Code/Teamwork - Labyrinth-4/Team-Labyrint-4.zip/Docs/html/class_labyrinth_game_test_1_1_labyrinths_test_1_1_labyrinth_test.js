var class_labyrinth_game_test_1_1_labyrinths_test_1_1_labyrinth_test =
[
    [ "ChangeSymbolInDiamondLabyrinthTest", "class_labyrinth_game_test_1_1_labyrinths_test_1_1_labyrinth_test.html#ada01c1e4d52848da2f2cd523f771f1f7", null ],
    [ "ChangeSymbolInHexagonalLabyrinthTest", "class_labyrinth_game_test_1_1_labyrinths_test_1_1_labyrinth_test.html#a9cbcb41b802b066d1792fc24e06c0091", null ],
    [ "ChangeSymbolInPentagonLabyrinthTest", "class_labyrinth_game_test_1_1_labyrinths_test_1_1_labyrinth_test.html#ad58b363e7814874cbbc70a30e8305793", null ],
    [ "ChangeSymbolInSquareLabyrinthTest", "class_labyrinth_game_test_1_1_labyrinths_test_1_1_labyrinth_test.html#aa19311dcd37e3d66e7eaa9da36cc37dd", null ]
];