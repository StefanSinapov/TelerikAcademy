var class_labyrinth_game_test_1_1_labyrinths_test_1_1_diamond_labyrinth_test =
[
    [ "IsDiamnodLabyrinthMatrixFilled", "class_labyrinth_game_test_1_1_labyrinths_test_1_1_diamond_labyrinth_test.html#a5380f682a09e0486b59dd35a1d1f315b", null ]
];