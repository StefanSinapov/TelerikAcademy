var interface_labyrinth_game_1_1_interfaces_1_1_i_score =
[
    [ "AddScore", "interface_labyrinth_game_1_1_interfaces_1_1_i_score.html#a7f58318fb964f105a7dc3f9020e07822", null ],
    [ "PrintScoreBoard", "interface_labyrinth_game_1_1_interfaces_1_1_i_score.html#adbb9c4d1b98d5c198bb4bad7af6ffa32", null ],
    [ "ScoreBoard", "interface_labyrinth_game_1_1_interfaces_1_1_i_score.html#a5c21c141ce25c24c8b1a388068c9843c", null ]
];