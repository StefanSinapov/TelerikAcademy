var dir_4f97551fd3a068a2ebeb6f7cc6c87f32 =
[
    [ "NinjectConfiguration.cs", "_ninject_configuration_8cs_source.html", null ]
];