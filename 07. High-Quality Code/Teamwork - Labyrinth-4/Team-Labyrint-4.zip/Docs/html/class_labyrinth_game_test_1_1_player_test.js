var class_labyrinth_game_test_1_1_player_test =
[
    [ "GetNamePlayerTrue", "class_labyrinth_game_test_1_1_player_test.html#a373be26164636a303e77dae8745f7bbd", null ],
    [ "RemovePlayerTrueTest", "class_labyrinth_game_test_1_1_player_test.html#ae3b0910d2a59fcf1a17f62358ddfc047", null ],
    [ "SetNamePlayerNullDefaultResult", "class_labyrinth_game_test_1_1_player_test.html#ac52f0c03bc275e7e7d15753dc44b2fbb", null ],
    [ "SetNamePlayerWithEmptyStringResult", "class_labyrinth_game_test_1_1_player_test.html#a3b11462d57fadf777a7b89f8517ccef0", null ],
    [ "ShowPlayerTrueTest", "class_labyrinth_game_test_1_1_player_test.html#a6fb3814e5e97a10c3928f85f2929b0e7", null ],
    [ "UpdatePointsTrue", "class_labyrinth_game_test_1_1_player_test.html#a0992d32fcd104098f7297527bcf736b7", null ],
    [ "UpdatePosition0x0RowChangedTest", "class_labyrinth_game_test_1_1_player_test.html#a07b921c06a8775c83f0773221e2de4c5", null ],
    [ "UpdatePosition0x1RowChangedTest", "class_labyrinth_game_test_1_1_player_test.html#a72fa4a12a1230e0e9474c503f619fd0b", null ],
    [ "UpdatePosition0xNegatiw1RowChangedTest", "class_labyrinth_game_test_1_1_player_test.html#a4a9766783cbd139b2941b07f9448f1a0", null ],
    [ "UpdatePosition1x0RowChangedTest", "class_labyrinth_game_test_1_1_player_test.html#ad0f21e81e955dc92818851f3b05124aa", null ],
    [ "UpdatePositionNegative1x0RowChangedTest", "class_labyrinth_game_test_1_1_player_test.html#a8beac5b2440dd284e29fddb2a124f2a0", null ]
];