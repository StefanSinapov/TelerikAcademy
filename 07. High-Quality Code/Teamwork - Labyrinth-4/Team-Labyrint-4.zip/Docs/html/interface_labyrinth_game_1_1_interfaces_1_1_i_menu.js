var interface_labyrinth_game_1_1_interfaces_1_1_i_menu =
[
    [ "GetLabyrinthTypeFromUser", "interface_labyrinth_game_1_1_interfaces_1_1_i_menu.html#ad4f4a4a4c1c42c2b393bcd3a1e0cf6a3", null ],
    [ "GetUserChoice", "interface_labyrinth_game_1_1_interfaces_1_1_i_menu.html#a603775084a102a188f3daa186c66d4ef", null ],
    [ "MainMenu", "interface_labyrinth_game_1_1_interfaces_1_1_i_menu.html#ab30cce6440656cd63ab3e614c9450859", null ],
    [ "MenuDuringPlay", "interface_labyrinth_game_1_1_interfaces_1_1_i_menu.html#a5c6b9028f1c5e6b0f0c59278bf877cab", null ]
];