var namespaces =
[
    [ "LabyrinthGame", "namespace_labyrinth_game.html", "namespace_labyrinth_game" ],
    [ "LabyrinthGameDemo", "namespace_labyrinth_game_demo.html", null ],
    [ "LabyrinthGameTest", "namespace_labyrinth_game_test.html", "namespace_labyrinth_game_test" ]
];