var class_labyrinth_game_test_1_1_menu_test =
[
    [ "MenuGetChoiceTypeDiamondTest", "class_labyrinth_game_test_1_1_menu_test.html#aa0e27f453254a81aebeb5a42af28641d", null ],
    [ "MenuGetChoiceTypeHexagonTest", "class_labyrinth_game_test_1_1_menu_test.html#abbcecbffeff90f67e45a2383b7d9ebc1", null ],
    [ "MenuGetChoiceTypePentagonTest", "class_labyrinth_game_test_1_1_menu_test.html#a1629560e75f4e655088260f3147b2373", null ],
    [ "MenuGetChoiceTypeSquareTest", "class_labyrinth_game_test_1_1_menu_test.html#ad46d78ac5a9ee38d3e1751837bf2f803", null ],
    [ "MenuGetUserChoice1Test", "class_labyrinth_game_test_1_1_menu_test.html#ad6d29162f529492326a034a77de9d8d7", null ],
    [ "MenuGetUserChoice2Test", "class_labyrinth_game_test_1_1_menu_test.html#a869de3700632de4d45add3edd8052c88", null ],
    [ "MenuGetUserChoice3Test", "class_labyrinth_game_test_1_1_menu_test.html#acb105bd68e81232c3a7a1766bade610b", null ],
    [ "MenuGetUserChoice4Test", "class_labyrinth_game_test_1_1_menu_test.html#ad981e2fe5f4a62b9c2cb42845f5ed2e5", null ],
    [ "TestMainMenu", "class_labyrinth_game_test_1_1_menu_test.html#ac987aeaee4777f46b96eb638821e65bf", null ],
    [ "TestMenuDuringPlay", "class_labyrinth_game_test_1_1_menu_test.html#a570bfb5f53160e0bbdcec5c0e08a32a8", null ]
];