var class_labyrinth_game_1_1_labyrinth_creator =
[
    [ "LabyrinthCreator", "class_labyrinth_game_1_1_labyrinth_creator.html#aa3cc87ea023705ad0d3cf262bb41a8c9", null ],
    [ "Create", "class_labyrinth_game_1_1_labyrinth_creator.html#a5159143053a5877414b8b68561e76a4a", null ]
];