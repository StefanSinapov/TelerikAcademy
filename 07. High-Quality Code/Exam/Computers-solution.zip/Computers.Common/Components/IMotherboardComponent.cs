﻿namespace Computers.Common.Components
{
    public interface IMotherboardComponent
    {
        IMotherboard Motherboard { get; set; }
    }
}
